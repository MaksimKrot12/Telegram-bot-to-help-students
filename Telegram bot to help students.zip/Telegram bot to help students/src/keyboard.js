const kb = require('./keyboard-buttons')

module.exports = {
    Home: [
        [kb.Home.аddition, kb.Home.pending],
    ],


    film: [


    ]

}
module.exports = {
    TOKEN: '7560857264:AAF4Pfif0kBRT_Lq9pKdn9tyLGEolkRdudM'
}
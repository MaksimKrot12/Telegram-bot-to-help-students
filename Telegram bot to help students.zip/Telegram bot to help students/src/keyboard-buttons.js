module.exports = {
    Home: {
        аddition:'Добавить группу',
        pending: 'Группы, что ожидают добавление'
    },
    
    Tasks: {
        Return:'',
    },

    Addition: {

    }

}